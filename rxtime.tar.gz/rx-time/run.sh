node rxtractor.js $1
./parse.out
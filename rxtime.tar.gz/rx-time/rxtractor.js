// Imports the Google Cloud client library
const vision = require('@google-cloud/vision');

// const admin = require('firebase-admin');
// 
// admin.initializeApp({
//     credential: admin.credential.applicationDefault()
// });
// 
// const db = admin.firestore();
// 
// const prompt = require('prompt-sync')();

const picture = process.argv[2]

process.env.GOOGLE_APPLICATION_CREDENTIALS="./rxtime.json"
async function rxtractor() {
    try {
        // Creates a client
        const client = new vision.ImageAnnotatorClient();

        // Performs text detection on the local file
        const [result] = await client.textDetection(picture);
        const detections = result.textAnnotations;
        const [ text, ...others ] = detections;
        fs = require('fs');
        fs.writeFile('Prescription_Details.txt', `${ text.description }`, function (err) {
        if (err) return console.log(err);
        console.log('Prescription > Prescription_Details.txt');
        });
    } catch (error) {
        console.log(error)
    }
    
    //const docRef = db.collection('prescriptions').doc('test');

    //await docRef.set('./Prescription_Details.txt')

    //await docRef.set('./Prescription_Details.txt')
}

rxtractor()
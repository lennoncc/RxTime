#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

int main() {
  std::string intake;
  std::string medicine;
  std::string amount;
  std::string type;
  std::string time;
  std::string occurance;
  int occur = 0;

  std::ifstream fileStream1("Prescription_Details.txt");  // reads name of file
  if (!fileStream1.is_open())  // error msg in case file can't open
  {
      std::cout << "Error: cannot open file Prescription_Details.txt"  << std::endl;
      std::exit(1);
  }

  std::getline (fileStream1,medicine);
  std::getline (fileStream1,medicine);

  while (fileStream1 >> intake) {
    if(intake == "take" || intake == "Take" || intake == "TAKE" || intake == "place" 
       || intake == "Place" || intake == "PLACE") {
         while (fileStream1 >> amount) {
           if(amount == "1" || amount == "2" || amount == "3" || amount == "3" || amount == "4" || amount == "5" || 
              amount == "6" || amount == "7" || amount == "8" || amount == "9" || amount == "one" || amount == "One" || 
              amount == "ONE" || amount == "two" || amount == "Two" || amount == "TWO" || amount == "three" || amount == "Three" || 
              amount == "THREE" || amount == "four" || amount == "Four" || amount == "FOUR" || amount == "five" || amount == "Five" || 
              amount == "FIVE" || amount == "six" || amount == "Six" || amount == "SIX" || amount == "seven" || amount == "Seven" || 
              amount == "SEVEN" || amount == "eight" || amount == "Eight" || amount == "EIGHT" || amount == "nine" || amount == "Nine" || 
              amount == "NINE") {
                fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

               fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

               fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

               fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

               fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

               fileStream1 >> type;
                while (fileStream1 >> time) {
                  if (time == "daily" || time == "Daily" || time == "DAILY" || time == "everyday" || time == "Everyday" || time == "EVERYDAY" ) {
                    time = "DAILY";
                    break;
                  }
                  if (time == "every" || time == "Every" || time == "EVERY") {
                    fileStream1 >> occurance;
                    time = "DAILY";
                    if (occurance == "1" ||  occurance == "one" || occurance == "One" || occurance == "ONE" || occurance == "day"
                        || occurance == "Day" || occurance == "DAY") {
                      occur = 1;
                    }
                    if (occurance == "2" ||  occurance == "two" || occurance == "Two" || occurance == "TWO") {
                      occur = 2;
                    }
                    if (occurance == "3" ||  occurance == "three" || occurance == "Three" || occurance == "THREE") {
                      occur = 3;
                    }
                    if (occurance == "4" ||  occurance == "four" || occurance == "Four" || occurance == "FOUR") {
                      occur = 4;
                    }
                    if (occurance == "5" ||  occurance == "five" || occurance == "Five" || occurance == "FIVE") {
                      occur = 5;
                    }
                    if (occurance == "6" ||  occurance == "six" || occurance == "Six" || occurance == "SIX") {
                      occur = 6;
                    }
                    if (occurance == "7" ||  occurance == "seven" || occurance == "Seven" || occurance == "SEVEN" ||
                        occurance == "week" || occurance == "Week" || occurance == "WEEK") {
                      time = "WEEKLY";
                    }
                    break;
                  }
                }
            break;
            } 

         }
        break;
       }
  }
  std::for_each(medicine.begin(), medicine.end(), [](char & c){
    c = ::tolower(c);
  });
  std::for_each(type.begin(), type.end(), [](char & c){
    c = ::tolower(c);
  });
  fileStream1.close();
  std::ofstream outfile;
  outfile.open ("formatted.txt");
  outfile << "Take " << amount << " " << type << " of " << medicine << std::endl;
  outfile << "RRULE:FREQ=" << time;
  if (occur > 1) {
    outfile << ";INTERVAL=" << occur;
  }
  outfile << std::endl;


  // std::cout << "intake: " << intake << std::endl;
  // std::cout << "medicine: " << medicine << std::endl;
  // std::cout << "amount: " << amount << std::endl;
  // std::cout << "type: " << type << std::endl;
  // std::cout << "time: " << time << std::endl;
  // std::cout << "occurance: " << occurance << std::endl;
  // std::cout << "occur: " << occur << std::endl;
}

